import heapq

# Define grid constants
START = 'S'
GOAL = 'G'
OBSTACLE = 'X'
OPEN_SPACE = '.'

# Define movements (up, down, left, right, and diagonals)
MOVES = [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)]

def heuristic(node, goal):
    # Calculate the Manhattan distance as the heuristic
    return abs(node[0] - goal[0]) + abs(node[1] - goal[1])

def a_star(grid, start, goal):
    # Define a priority queue for the open set
    open_set = []
    heapq.heappush(open_set, (0, start))

    # Create dictionaries to track costs and parent nodes
    g_score = {start: 0}
    parent = {start: None}

    while open_set:
        _, current = heapq.heappop(open_set)

        if current == goal:
            # Reconstruct the path
            path = []
            while current:
                path.append(current)
                current = parent[current]
            path.reverse()
            return path

        for move in MOVES:
            neighbor = (current[0] + move[0], current[1] + move[1])

            if neighbor[0] < 0 or neighbor[0] >= len(grid) or neighbor[1] < 0 or neighbor[1] >= len(grid[0]) or grid[neighbor[0]][neighbor[1]] == OBSTACLE:
                continue

            tentative_g_score = g_score[current] + 1

            if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                g_score[neighbor] = tentative_g_score
                f_score = tentative_g_score + heuristic(neighbor, goal)
                heapq.heappush(open_set, (f_score, neighbor))
                parent[neighbor] = current

    return None  # No path found

# Example usage
grid = [
    "S..X.....",
    ".X.......",
    ".X.X.....",
    "....X....",
    "..X..X...",
    "...X...X.",
    "......X..",
    "........G"
]

# Convert the grid to a list of lists
grid = [list(row) for row in grid]
print(grid)

start_pos = (0, 0)
goal_pos = len(grid)
